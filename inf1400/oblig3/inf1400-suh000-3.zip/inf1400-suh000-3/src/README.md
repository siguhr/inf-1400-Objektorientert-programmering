# oblig3
To run game:

1. Open terminal.
2. Run the main3 file trough terimial or eiditor. Remember to have the config.py file in the same folder. 
3. Run main3 file.

4. Player 1: use arrow up for trust, right and left to rotate.
5. Player 2: use w to trust, a and d to rotate. 
6. Player 1: use space to shoot.
7. Player 2: use ctrl to shoot. 

8. This code is written on VSC in ubuntu terminal.
