# -*- coding: utf-8 -*-
"""
Created on Mon Mar 22 11:21:07 2021

@author: martin
"""

import pygame
from random import randint
from pygame import Vector2
import sys

#Initialising pygame 
pygame.init()

#Colormap
WHITE = (255,255,255)
RED = (255,25,0)
BLACK = (0,0,0)
PINK = (255,15,219)

#Display
pygame.display.set_caption("Oblig 3: Mayhem Clone")

#Game window
SCREEN_X = 1000
SCREEN_Y = 700
SCREEN = pygame.display.set_mode((SCREEN_X, SCREEN_Y), 0, 32)

#Globals
game_running = True
spaceship_size = (60, 60)
FPS = 60
counterclockwise = 1
clockwise = -1


#Images
# spaceship_image = pygame.Surface((60, 60))
# spaceship_image.fill(RED)


spaceship_image = pygame.image.load("spaceship.png")
spaceship_image = spaceship_image.convert_alpha()
spaceship_image = pygame.transform.scale(spaceship_image, spaceship_size)


#class
class spaceship(pygame.sprite.Sprite):
    def __init__(self, image, position, heading, velocity, acceleration, gravity):
        super().__init__()
        self.image = image
        self.position = position
        self.heading = heading
        self.velocity = velocity
        self.acceleration = acceleration
        self.gravity = gravity
        self.angle = 0
        self.angle_speed = 10
        
        self.original_image = self.image
        
        
        self.rect = self.image.get_rect() 
        self.rect.center = self.position
    
        
    
        
    def update(self):
        pass

        
    def rotate(self, direction_rotation):        
        if self.angle > 360 or self.angle == 360:
            self.angle -= 360
        if self.angle < -360 or self.angle == -360:
            self.angle += 360
        if direction_rotation == 1:  #Counterclockwise rotation
            self.rotated_image = pygame.transform.rotozoom(self.original_image, direction_rotation*(self.angle + self.angle_speed), 1)             
        if direction_rotation == -1: #Clockwise rotation
            self.rotated_image = pygame.transform.rotozoom(self.original_image, (self.angle - self.angle_speed), 1) 

        self.rotated_rectangle = self.rotated_image.get_rect() 
        
        
        self.image = self.rotated_image
        self.rect = self.rotated_rectangle
        
        self.rect.center = self.position
        
        
    def reset_rotation(self):
        self.image = self.original_image
        self.rect = self.original_image.get_rect() 
        self.rect.center = self.position
        
    def move():
        pass
    
    def shoot():
        pass
    
    def refuel():
        pass
        
#Sound class       
class soundeffects:
    def __init__(self, sound):
        self.sound = pygame.mixer.Sound(sound)
    
    def play(self):
        self.sound.play()
        
    def stop(self):
        self.sound.stop()
        

#sound_HS = soundeffects("Harlem_Shake.wav")


#Creating objects
#Spaceship
spaceship_group = pygame.sprite.Group()

spaceship1 = spaceship(spaceship_image, Vector2(500,300), 0, 0, 0, 0)

spaceship_group.add(spaceship1)

#Frame rate limit
clock = pygame.time.Clock()

while game_running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            print("Bye bye")
            pygame.quit()
            sys.exit()  
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                spaceship1.rotate(counterclockwise) 
                spaceship1.angle += spaceship1.angle_speed
                print(spaceship1.angle)
                
            if event.key == pygame.K_RIGHT:  
                spaceship1.rotate(clockwise)  
                spaceship1.angle -= spaceship1.angle_speed
                print(spaceship1.angle)
            
    #Displaying background on the screen (window)
    pygame.draw.rect(SCREEN, WHITE, (0,0,SCREEN_X,SCREEN_Y))
    
    
    #Draw spaceship        
    spaceship_group.draw(SCREEN)   #Uses image and rect variables to blit inside the sprite class
    # for ship in spaceship_group:
    #     ship.reset_rotation()
    
    
    #Handle spaceship
    spaceship_group.update()
        
    
    #Update
    pygame.display.update()
    