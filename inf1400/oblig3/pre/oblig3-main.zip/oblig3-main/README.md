# oblig3
gg
DIPPA DOUBLE G
no you da double g
